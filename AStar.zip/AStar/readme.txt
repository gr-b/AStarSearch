Griffin Bishop
David Deisde
Gianluca Tarquinio
Ian Vossoughi

CS4341: Assignment 1 - A* Search

This program, written in Python, can read in a robot world and produce the optimal
solution to the robot navigating this world.

To run this program, unzip the Zip folder, navigate to this folder using the terminal,
and use the following command line command:
> python astar.py [saved world] [heuristic 1-6]

For instance, to run the world “world-3” using Heuristic 5, you would type:
python astar.py world-3 5

The program will output the solution’s score, number of actions, nodes expanded, estimated
branching factor, and a list of the robots actions to reach the goal.